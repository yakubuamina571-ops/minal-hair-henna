import Image from "next/image";

export default function Portfolio() {
  return (
    <main className="px-6 py-12 text-center">
      <h1 className="text-3xl font-semibold text-purple-700 mb-2">Our Portfolio</h1>
      <p className="mb-8 text-gray-600">Showcasing our beautiful henna and hairstyling work.</p>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Image src="/henna1.jpg" alt="Henna design on palms" width={400} height={400} className="rounded-xl shadow" />
        <Image src="/hair1.jpg" alt="Traditional braided hairstyle" width={400} height={400} className="rounded-xl shadow" />
        <Image src="/henna2.jpg" alt="Henna design on hands & arms" width={400} height={400} className="rounded-xl shadow" />
      </div>
    </main>
  );
}
