export default function About() {
  return (
    <main className="px-6 py-12 max-w-3xl mx-auto">
      <h1 className="text-3xl font-semibold text-purple-700 mb-4">About Hair & Henna Fusion</h1>
      <p className="mb-4">
        Hair & Henna Fusion is an empowerment initiative based in Dutse, Jigawa State,
        focused on training women in the cultural arts of hairstyling and henna design.
      </p>
      <p>
        Our mission is to create cultural pride, social inclusion, and financial
        independence for women and youth. We envision a future where Jigawa becomes a hub
        for authentic bridal artistry and sustainable women-owned businesses.
      </p>
    </main>
  );
}
