# minal-hair-henna — Deploy-ready (Hair & Henna Fusion)

This repository contains a Next.js (App Router) starter site pre-configured with TailwindCSS
and placeholder images inside `/public`. Use the instructions below to push to GitHub and deploy on Vercel.

## Quick steps (recommended: Vercel web UI)

1. Extract this package if you downloaded a zip, or open the project folder locally.
2. Create a new repository on GitHub named `minal-hair-henna` (or any name you prefer).
   - On GitHub, click **New repository** → name it → Create repository.
3. Push the project to GitHub:

   ```bash
   cd path/to/minal-hair-henna
   git init
   git add .
   git commit -m "Initial commit — deploy-ready"
   git branch -M main
   git remote add origin https://github.com/YOUR_GITHUB_USERNAME/minal-hair-henna.git
   git push -u origin main
   ```

4. Deploy on Vercel (via web):
   - Go to https://vercel.com and **Login with GitHub**.
   - Click **New Project** → Import from GitHub → select `minal-hair-henna` repo.
   - Vercel should auto-detect Next.js. Use default build command `npm run build`.
   - Click **Deploy**. After build completes, Vercel will provide the site URL (example: https://minal-hair-henna.vercel.app).

## Alternative: deploy via Vercel CLI

```bash
npm i -g vercel
vercel login            # follow the browser link to login
cd path/to/minal-hair-henna
vercel --prod           # follow prompts; this will publish a production deployment
```

## Notes & troubleshooting
- If Vercel fails due to Node version, this project contains `.nvmrc` with Node 18. In the Vercel dashboard, set the Node version to 18 or add `engines` in package.json.
- If you see an error complaining about missing `app` or `pages`, ensure the `app/` directory is present at the repository root (it is included).
- If the build fails, paste the Vercel build log and I can help debug specific errors.

## Replace placeholder images
Replace the files in `/public` with your real images keeping the same names (`henna1.jpg`, `henna2.jpg`, `hair1.jpg`) or update the `app/portfolio/page.js` image paths.

---
If you'd like, I can also create the GitHub repo README, a LICENSE file, or help debug a failing Vercel build if you paste the logs here.
